﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Eileen")
define m = Character("Eu")


# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bg room

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    m "(Finalmente acabou.)"

    m "(Passei os ultimos 50 minutos olhando fixamente para o relógio em cima do quadro negro.)"

    m "(Mal podia esperar para que essa maldita aula acabasse.)"

    m "(Antes que eu possa me levantar da cadeira, ouço passos rápidos se aproximando de mim.)"

    show eileen happy

    # These display lines of dialogue.

    e "Oiii~~"

    e "Eu 'tava querendo falar com você!"

    e "Ontem você não veio, fiquei preocupada!"

    m "(Ela dá um giro no lugar, fazendo uma pose quando termina.)"

    e "E aí? O que achou do meu corte de cabelo novo?"


    menu:
        "Ficou legal.":
            jump achou_bonito

        "Achei meio feio.":
            jump achou_feio

label achou_bonito:

        m "Achei legal, você ficou bonita."

        show eileen blush
        
        m "(O sorriso dela se abre ainda mais, um rubbor subindo ás suas bochechas.)"

        e "Hehehe! Que bom que você gostou!"

        m "(Ela coloca sua mão sobre a minha.)"

        e "Quer ir comer alguma coisa comigo? Conheço um restaurante bem legal aqui perto!"

        m "Pode ser."

        m "(Ela me puxa pela mão e vamos até o tal restaurante.)"

        return

label achou_feio:

        m "Olha, pra ser sincero, achei meio feio."

        show eileen sad

        m "(O sorriso cai de seu rosto e seus olhos se enchem de lágrimas.)"

        e "Ah... que pena..."

        m "(Ela esfrega os olhos rapidamente e da uma fungada.)"

        e "B-bem... eu vou pra casa então..."

        m "(Ela se vira e vai embora cabisbaixa.)"

        return



    # This ends the game.

